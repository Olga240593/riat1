﻿using System.Runtime.Serialization;


namespace RIAT_LAB_2
{
    [DataContract]
    public class Input
    {
        [DataMember(Order = 1)]
        public int K { get; set; }
        [DataMember(Order = 2)]
        public decimal[] Sums { get; set; }
        [DataMember(Order = 3)]
        public int[] Muls { get; set; }
    }
}
