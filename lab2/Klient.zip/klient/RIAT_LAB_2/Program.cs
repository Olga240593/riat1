﻿using System;
using System.Text;

namespace RIAT_LAB_2
{
    class Program 
    {
        static void Main(string[] args)
        {
            BacsClient bacs = new BacsClient(Console.ReadLine());
            IBacsClient iBacs = bacs;
            if (iBacs.Ping())
            {
                var someData = iBacs.GetInputData();
                var serializedInput = Encoding.UTF8.GetString(someData.Result);
                var buffer = iBacs.ConvertInputData(serializedInput);
                iBacs.WriteAnswer(buffer);
            }
        }
    }
}
