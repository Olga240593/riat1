﻿using System;

namespace RIAT_LAB_2
{
    interface ISerializer
    {
        string Serialize<T>(T someData);
        T Deserialize<T>(string serializedString);
        object GetSerializer(Type key);
    }
}
