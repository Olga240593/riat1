﻿using System.Threading.Tasks;

namespace RIAT_LAB_2
{
    interface IBacsClient
    {
        bool Ping();
        Task<byte[]> GetInputData();
        byte[] ConvertInputData(string inputData);
        void WriteAnswer(byte[] buf);
    }
}
