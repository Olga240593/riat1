﻿using System.Runtime.Serialization;

namespace RIAT_LAB_2
{
    [DataContract]
    public class Output
    {
        [DataMember(Order = 1)]
        public decimal SumResult { get; set; }
        [DataMember(Order = 2)]
        public int MulResult { get; set; }
        [DataMember(Order = 3)]
        public decimal[] SortedInputs { get; set; }
        public Output()
        {
            SumResult = 0;
            MulResult = 1;
        }
    }
}
