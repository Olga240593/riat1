﻿using System;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;

namespace RIAT_LAB_2
{

    public class BacsClient : IBacsClient
    {
        private string baseUrl { get; set; }

        public BacsClient(string port)
        {
            baseUrl = String.Format("http://127.0.0.1:{0}", port);
        }

        bool IBacsClient.Ping()
        {
            using (var client = new HttpClient())
            {
                var method = "/Ping";
                client.BaseAddress = new Uri(baseUrl);
                var response = client.GetAsync(method);
                return response.Result.IsSuccessStatusCode;
            }
        }

        async Task<byte[]> IBacsClient.GetInputData()
        {
            using (var client = new HttpClient())
            {
                var method = "/GetInputData";
                client.BaseAddress = new Uri(baseUrl);
                var response = await client.GetByteArrayAsync(method);
                return response;
            }
        }

        void IBacsClient.WriteAnswer(byte[] buf)
        {
            using (var client = new HttpClient())
            {
                var method = "/WriteAnswer";
                client.BaseAddress = new Uri(baseUrl);
                HttpContent content = new ByteArrayContent(buf);
                HttpContent httpContent = null;
                var response = client.PostAsync(method, content)
                                    .ContinueWith(responseTask => {
                                        httpContent = responseTask.Result.Content;
                                    });
                response.Wait();
                string responseFromServer = httpContent.ReadAsStringAsync().Result;
            }
        }

        byte[] IBacsClient.ConvertInputData(string inputData)
        {
            JsonSerialize jss = new JsonSerialize();
            Input someInput = jss.Deserialize<Input>(inputData);
            Output someOutput = InputToOutput.MakeOutputFromInput(someInput);
            string serializedOutput = jss.Serialize<Output>(someOutput);
            return Encoding.UTF8.GetBytes(serializedOutput);
        }
    }
}
