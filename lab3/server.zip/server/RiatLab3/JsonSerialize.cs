﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Json;

namespace RiatLab3
{
    class JsonSerialize : ISerializer
    {
        private Hashtable serializers=new Hashtable();

        public object GetSerializer(Type key)
        {
            if (serializers.ContainsKey(key))
            {
                return (object) serializers[key];
            }
            else
            {
                serializers.Add(key, new DataContractJsonSerializer(key));
                return (object)serializers[key];
            }
        }

        public T Deserialize<T>(string serializedString)
        {
            MemoryStream stream = new MemoryStream();
            DataContractJsonSerializer serializer = (DataContractJsonSerializer)GetSerializer(typeof(T));
            StreamWriter sw = new StreamWriter(stream);
            sw.Write(serializedString);
            sw.Flush();
            stream.Position = 0;
            return (T)serializer.ReadObject(stream);
        }

        public string Serialize<T>(T someData)
        {
            MemoryStream stream = new MemoryStream();
            DataContractJsonSerializer serializer = (DataContractJsonSerializer)GetSerializer(typeof(T));
            serializer.WriteObject(stream, someData);
            stream.Position = 0;
            string res;
            using (StreamReader sr = new StreamReader(stream))
            {
                res = sr.ReadToEnd();
                sr.Close();
                sr.Dispose();
            }
            return res;
        }
    }
}
