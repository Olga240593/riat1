﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.Text.RegularExpressions;
using System.IO;

namespace RiatLab3
{
    class Program
    {
        static void Main(string[] args)
        {
            new Listener(int.Parse(Console.ReadLine()));
        }
    }
}
