﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.Text.RegularExpressions;
using System.IO;
using System.Reflection;

namespace RiatLab3
{
    class Server
    {
        public bool powerOn { get; set; }
        private JsonSerialize jsonSerializer = new JsonSerialize();
        private Input input { get; set; }
        private Output output { get; set; }

        private string ReadClientMessage(TcpClient Client)
        {
            byte[] Buffer = new byte[Client.ReceiveBufferSize];
            int count;
            try
            {
                count = Client.GetStream().Read(Buffer, 0, Buffer.Length);
                return (count > 0) ? Encoding.UTF8.GetString(Buffer, 0, count) : null;
            }
            catch
            {
                Client.Close();
                return null;
            }
        }
        public void Start(TcpClient Client)
        {
            string Request = ReadClientMessage(Client);
            if (!Client.Connected) return;
            Match ReqMatch = Regex.Match(Request, @"^\w+\s+[\W]+([^\s\?]+)[^\s]*\s+HTTP/.*|");
            if (ReqMatch == Match.Empty)
            {
                SendError(Client, 400);
                return;
            }
            
            string RequestUri = String.Empty;
            RequestUri = ReqMatch.Groups[1].Value;
            RequestUri = Uri.UnescapeDataString(RequestUri);
            
            if (RequestUri.IndexOf("..") >= 0)
            {
                SendError(Client, 400);
                return;
            }
            var methods = this.GetType().GetMethods(BindingFlags.NonPublic | BindingFlags.Instance);
            foreach(var method in methods)
            {
                if(method.Name==RequestUri)
                {
                    method.Invoke(this, (method.GetParameters().Length == 1) ? new object[] { Client }
                    : new object[] { Client, Request });
                    return;
                }
            }
            SendError(Client,404);
        }

        private void SendError(TcpClient Client, int Code)
        {
            string MessageText = String.Format("HTTP/1.1 {0} {1}\n\n",Code,(HttpStatusCode)Code);
            byte[] buf = Encoding.UTF8.GetBytes(MessageText);
            Client.GetStream().Write(buf, 0, buf.Length);
            Client.Close();
        }

        public Server()
        {
            powerOn = true;
        }

        private void Ping(TcpClient Client)
        {
            string MessageText = "HTTP/1.1 200 OK\nContent-type: text/json\nContent-Length:0\n\n";
            byte[] buf = Encoding.UTF8.GetBytes(MessageText);
            Client.GetStream().Write(buf, 0, buf.Length);
            Client.Close();
        }

        private void GetAnswer(TcpClient Client)
        {
            output = InputToOutput.MakeOutputFromInput(input);
            string jsonObj = jsonSerializer.Serialize<Output>(output);
            string MessageText = String.Format("HTTP/1.1 200 OK\nContent-type: text/json\nContent-Length:{0}\n\n{1}",
                                            jsonObj.Length,
                                            jsonObj);
            byte[] buf = Encoding.UTF8.GetBytes(MessageText);
            Client.GetStream().Write(buf, 0, buf.Length);
            Client.Close();
        }
        private void PostInputData(TcpClient Client, string Request)
        {
            try {
                if (Request.IndexOf("Expect: 100-continue") > 0)
                {
                    Request = Expect100Handler(Client);
                    if (!Client.Connected) return;
                }
                string serializedInput = String.Empty;
                int iterator = Request.IndexOf('{');
                serializedInput = Request;
                input = jsonSerializer.Deserialize<Input>(serializedInput);
                string MessageText = "HTTP/1.1 200 OK\nContent-type: text/json\nContent-Length:0\n\n";
                byte[] buf = Encoding.UTF8.GetBytes(MessageText);
                Client.GetStream().Write(buf, 0, buf.Length);
                Client.Close();
            }
            catch
            {
                SendError(Client, 400);
            }
        }
        private void Stop(TcpClient Client)
        {
            string MessageText = "HTTP/1.1 200 OK\nContent-type: text/json\nContent-Length:0\n\n";
            byte[] buf = Encoding.UTF8.GetBytes(MessageText);
            Client.GetStream().Write(buf, 0, buf.Length);
            Client.Close();
            powerOn = false;
        }
        private string Expect100Handler(TcpClient Client)
        {
            string MessageText = "HTTP/1.1 100 Continue\n\n";
            byte[] buf = Encoding.UTF8.GetBytes(MessageText);
            Client.GetStream().Write(buf, 0, buf.Length);
            return ReadClientMessage(Client);
        }
    }
}
