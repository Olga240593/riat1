﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiatLab3
{
    public class InputToOutput
    {
        public static Output MakeOutputFromInput(Input someInput)
        {
            Output Res = new Output();
            Res.SumResult = someInput.Sums.Sum() * someInput.K;
            Res.MulResult = someInput.Muls.Aggregate((acc, i) => acc * i);
            someInput.Sums = someInput.Sums.Select(i => (decimal) i + 0.0M).ToArray();
            Res.SortedInputs = someInput.Sums.Concat(someInput.Muls.Select(i => (decimal)i+0.0M)).OrderBy(x => x).ToArray();
            return Res;
        }
    }
}
