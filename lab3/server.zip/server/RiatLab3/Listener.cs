﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace RiatLab3
{
    public class Listener
    {
        TcpListener listener;
        Server server = new Server();
        public Listener(int Port)
        {
            listener = new TcpListener(IPAddress.Any, Port);
            listener.Start();
            do
            {

                GetClientRequest(listener.AcceptTcpClient());

            } while (server.powerOn);
        }

        void GetClientRequest(Object StateInfo)
        {
            server.Start((TcpClient)StateInfo);
            if (!server.powerOn) listener.Stop();
        }

        ~Listener()
        {
            if (listener != null)
            {
                listener.Stop();
            }
        }
    }
}
